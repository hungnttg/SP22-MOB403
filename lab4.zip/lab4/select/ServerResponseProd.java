package com.example.demo1.lab4.select;
//b2: Dinh nghia tap ket qua tra ve
public class ServerResponseProd {//GET
    private Prod[] products;//products khong duoc thay doi ten
    private String message;

    public Prod[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
