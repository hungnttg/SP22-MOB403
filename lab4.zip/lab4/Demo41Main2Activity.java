package com.example.demo1.lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;
import com.example.demo1.lab4.insert.InterfaceInsertPrd;
import com.example.demo1.lab4.insert.Prd;
import com.example.demo1.lab4.insert.SvrResponsePrd;
import com.example.demo1.lab4.select.InterfaceSelect;
import com.example.demo1.lab4.select.Prod;
import com.example.demo1.lab4.select.ServerResponseProd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Demo41Main2Activity extends AppCompatActivity {
    EditText txtName,txtPrice,txtDes;
    TextView tvKQ;
    Button btnInsert, btnGet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main2);
        txtName = findViewById(R.id.demo4TxtName);
        txtPrice = findViewById(R.id.demo4TxtPrice);
        txtDes = findViewById(R.id.demo4TxtDes);
        btnGet = findViewById(R.id.demo4BtnGet);
        btnInsert = findViewById(R.id.demo4BtnInsert);
        tvKQ = findViewById(R.id.demo4TvResult);
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectData();
            }
        });
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertData();
            }
        });
    }
    String strKQ="";
    List<Prod> ls;
    public void selectData()
    {
        strKQ="";
        //1. Tao doi tuong
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2.Goi ham select trong interface
        //2.1 tao doi tuong
        InterfaceSelect interfaceSelect
                =retrofit.create(InterfaceSelect.class);
        //2.2 chuan bi ham
        Call<ServerResponseProd> call = interfaceSelect.getProd();
        //2.3 thuc thi request
        call.enqueue(new Callback<ServerResponseProd>() {
            //thah cong
            @Override
            public void onResponse(Call<ServerResponseProd> call, Response<ServerResponseProd> response) {
               ServerResponseProd serverResponseProd = response.body();//lay ket qua tra ve
               //chuyen ket qua tu chuoi sang list
               ls = new ArrayList<>(Arrays.asList(serverResponseProd.getProducts()));
               for(Prod p: ls)
               {
                   strKQ += "Name: "+p.getName()+"; Price: "+p.getPrice()+"; Des: "+p.getDescription()+"\n\n";
               }
               tvKQ.setText(strKQ);
            }
            //that bai
            @Override
            public void onFailure(Call<ServerResponseProd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }

    public void insertData()//dung retrofit
    {
        //1. Tao doi tuong chua du lieu
        Prd prd = new Prd();
        //2. Dua du lieu nhap tren adroid vao doi tuong
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //3. Tao doi tuong retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //4. Goi ham insert trong interface
        //4.0 Tao doi tuong
        InterfaceInsertPrd insertPrdObj = retrofit.create(InterfaceInsertPrd.class);
        //4.1. chuan bi ham
        Call<SvrResponsePrd> call
                =insertPrdObj.insertPrd(prd.getName(),prd.getPrice(),prd.getDescription());
        //4.2 thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            //neu thanh cong
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd = response.body();//lay ket qua tra ve tu server
                tvKQ.setText(svrResponsePrd.getMessage());
            }
            //neu that bai
            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });

    }
}
