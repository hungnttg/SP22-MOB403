package com.example.demo1.lab4.insert;

public class SvrResponsePrd {//get
    private Prd products;
    private String message;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
