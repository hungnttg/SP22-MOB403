<?php
//0. Tao mang chua ket qua JSON
$response = array();
//1. Khai bao thong tin ket noi voi csdl
$server="localhost";
$u="";
$p="";
$db="";
//2. Tao ket noi csdl
$conn = new mysqli($server,$u,$p,$db);
//2.1 Kiem tra ket noi
if($conn->connect_error)
{
    die("Ket noi loi ". $conn->connect_error);//thong bao loi
}
//3. Kiểm tra chuyển dữ liệu vào API
if(isset($_GET['name'])&&isset($_GET['price'])&&isset($_GET['description']))
{
    $name = $_GET['name'];//đưa dữ liệu chuyển đến vào biến name
    $price = $_GET['price'];//đưa dữ liệu chuyển đến vào biến price
    $description = $_GET['description'];//đưa dữ liệu chuyển đến vào biến description
    //4. thuc hien insert du lieu
    $sql = "INSERT INTO products(name,price,description) VALUES ('$name','$price','$description')";
    if($conn->query($sql)==TRUE)//neu insert thanh cong
    {
        $response["success"]=1;
        $response["message"]="Insert thanh cong";
        //chuyen du lieu sang dang JSON
        echo json_encode($response);//
    }
    else
    {
        $response["success"]=0;
        $response["message"]="Loi Insert";
        //chuyen du lieu sang dang JSON
        echo json_encode($response);//
    }
}
$conn->close();//dong ket noi
?>