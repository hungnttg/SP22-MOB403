package com.example.demo1.lab52;

public class ConstUdt {
    public static final String BASE_URL = "https://batdongsanabc.000webhostapp.com/mob403lab5/";
}
