package com.example.demo1.lab52;

import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FunctionUdt {
    public void updateFn(TextView tvResult, PrdUdt p)
    {
        //1. Tao doi tuong
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstUdt.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2.Dua du lieu vao request
        RequestUdt requestUdt = new RequestUdt();
        requestUdt.setProducts(p);
        //3. goi interface
        InterfaceUdt interfaceUdt = retrofit.create(InterfaceUdt.class);
        Call<ResponseUdt> call =
                interfaceUdt.updateExe(p.getPid(),p.getName(),p.getPrice(),p.getDescription());
        //4. thuc thi
        call.enqueue(new Callback<ResponseUdt>() {
            @Override
            public void onResponse(Call<ResponseUdt> call, Response<ResponseUdt> response) {
                ResponseUdt responseUdt = response.body();
                tvResult.setText(responseUdt.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseUdt> call, Throwable t) {
                tvResult.setText(t.getMessage());
            }
        });
    }
}
