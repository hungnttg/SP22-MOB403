package com.example.demo1.lab52;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo52Main2Activity extends AppCompatActivity {
    EditText txtPid, txtName, txtPrice, txtDes;
    TextView tvResult;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo52_main2);
        txtPid = findViewById(R.id.demo52TxtPid);
        txtName = findViewById(R.id.demo52TxtName);
        txtPrice = findViewById(R.id.demo52TxtPrice);
        txtDes = findViewById(R.id.demo52TxtDes);
        btn  =findViewById(R.id.demo52Btn);
        tvResult = findViewById(R.id.demo52TvResult);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FunctionUdt f = new FunctionUdt();
                PrdUdt p = new PrdUdt();
                p.setPid(txtPid.getText().toString());
                p.setName(txtName.getText().toString());
                p.setPrice(txtPrice.getText().toString());
                p.setDescription(txtDes.getText().toString());
                f.updateFn(tvResult,p);
            }
        });
    }
}
