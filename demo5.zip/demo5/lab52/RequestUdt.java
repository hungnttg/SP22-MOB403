package com.example.demo1.lab52;

public class RequestUdt {//SET
    private PrdUdt products;

    public void setProducts(PrdUdt products) {
        this.products = products;
    }
}
