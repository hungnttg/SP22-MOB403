package com.example.demo1.lab52;

public class ResponseUdt {//GET
    private PrdUdt products;
    private String message;
    private String result;

    public PrdUdt getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
