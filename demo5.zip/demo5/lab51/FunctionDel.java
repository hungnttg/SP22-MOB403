package com.example.demo1.lab51;

import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FunctionDel {
    public void deleteFn(TextView tvResult, String pid)
    {
        //1. Tao doi tuong
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstDel.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. Dua du lieu vao request
        PrdDel p = new PrdDel();
        p.setPid(pid);

        RequestDel requestDel = new RequestDel();
        requestDel.setProducts(p);
        //3. goi interface (thuc thi ham + tra ket qua)
        InterfaceDel interfaceDel = retrofit.create(InterfaceDel.class);
        Call<ResponseDel> call = interfaceDel.deleteExe(pid);
        //4. Thuc thi
        call.enqueue(new Callback<ResponseDel>() {
            @Override
            public void onResponse(Call<ResponseDel> call, Response<ResponseDel> response) {
                ResponseDel responseDel = response.body();
                tvResult.setText(responseDel.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseDel> call, Throwable t) {
                tvResult.setText(t.getMessage());
            }
        });
    }
}
