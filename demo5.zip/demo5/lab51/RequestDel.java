package com.example.demo1.lab51;

public class RequestDel {//SET
    private PrdDel products;

    public void setProducts(PrdDel products) {
        this.products = products;
    }
}
