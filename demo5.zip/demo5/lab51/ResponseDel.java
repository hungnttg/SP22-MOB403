package com.example.demo1.lab51;

public class ResponseDel {//GET
    private PrdDel products;
    private String message;
    private String result;

    public PrdDel getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
