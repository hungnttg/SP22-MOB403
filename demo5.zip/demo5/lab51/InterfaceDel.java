package com.example.demo1.lab51;

import com.example.demo1.R;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceDel {
    @FormUrlEncoded
    @POST("delete_product.php")
    Call<ResponseDel> deleteExe(@Field("pid") String pid);

}
