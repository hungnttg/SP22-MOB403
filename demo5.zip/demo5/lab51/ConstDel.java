package com.example.demo1.lab51;

public class ConstDel {
    //1. Link
    public static final String BASE_URL = "https://batdongsanabc.000webhostapp.com/mob403lab5/";
}
