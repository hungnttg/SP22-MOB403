package com.example.demo1.lab51;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo51Main2Activity extends AppCompatActivity {
    EditText editText;
    TextView textView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main2);
        button = findViewById(R.id.demo51Btn1);
        editText = findViewById(R.id.demo51Edt1);
        textView = findViewById(R.id.demo51Tv1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pid = editText.getText().toString();
                FunctionDel f = new FunctionDel();
                f.deleteFn(textView,pid);
            }
        });
    }
}
