package com.example.demo1.lab51;

public class PrdDel {
    //2. model
    private String pid;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
