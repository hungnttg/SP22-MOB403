package com.example.demo1.demo7;

import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class FunctionDelete {
    public void delete_fn_POST(Context context, TextView textView)
    {
        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. url
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab5/delete_product.php";
        //3. Truyen tham so
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        textView.setText(response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        })
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String,String> mydata = new HashMap<>();
                mydata.put("pid","871");
                return mydata;
            }
        };
        //4. Xu ly request
        queue.add(stringRequest);
    }
}
