package com.example.demo1.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo71Main2Activity extends AppCompatActivity {
    EditText txtPid,txtName,txtPrice,txtDes;
    Button btnThem, btnXoa,btnHienThi,btnSua;
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        txtPid = findViewById(R.id.demo71txtPid);
        txtName = findViewById(R.id.demo71txtName);
        txtPrice = findViewById(R.id.demo71txtPrice);
        txtDes = findViewById(R.id.demo71txtDes);
        btnThem = findViewById(R.id.demo71Them);
        btnSua = findViewById(R.id.demo71Sua);
        btnXoa = findViewById(R.id.demo71Xoa);
        btnHienThi = findViewById(R.id.demo71HienThi);
        tvKQ = findViewById(R.id.demo71KQ);
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FunctionDelete fn = new FunctionDelete();
                fn.delete_fn_POST(getApplicationContext(),tvKQ);
            }
        });
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FunctionInsert fn = new FunctionInsert();
                fn.insert_fn_POST(getApplicationContext(),tvKQ,txtName,txtPrice,txtDes);
            }
        });
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FunctionUpdate fn = new FunctionUpdate();
                fn.update_fn_POST(getApplicationContext(),tvKQ,txtPid,txtName,txtPrice,txtDes);
            }
        });
    }
}
