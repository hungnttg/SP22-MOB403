package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.demo1.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class Demo22Main2Activity extends AppCompatActivity {
    TextView textView;
    ImageView imageView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        textView = findViewById(R.id.demo22TvKq);
        button = findViewById(R.id.demo22Btn);
        imageView = findViewById(R.id.demo22Img);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Demo22Async().execute("http://tinypic.com/images/goodbye.jpg");
            }
        });
    }
    public class Demo22Async extends AsyncTask<String,Void,Bitmap>
    {
        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                return BitmapFactory.decodeStream((InputStream)new URL(strings[0]).getContent());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(bitmap!=null)
            {
                imageView.setImageBitmap(bitmap);
            }
            else
            {
                textView.setText("Loi load anh");
            }
        }
    }
}
