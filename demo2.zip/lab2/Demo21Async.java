package com.example.demo1.lab2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class Demo21Async extends AsyncTask<String,Void, Bitmap> {
    private  Demo21Interface iListener;
    public Demo21Async(Demo21Interface listener, Context context)
    {
        iListener = listener;
    }
    //input
    @Override
    protected Bitmap doInBackground(String... strings) {
        try {
            return BitmapFactory.decodeStream((InputStream)new URL(strings[0]).getContent());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    //output

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        if(bitmap!=null)
        {
            iListener.onloadImage(bitmap);//ket qua tra ve qua interface
        }
        else
        {
            iListener.onLoi();//loi tra ve qua interface
        }
    }
    //qua trinh
    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
