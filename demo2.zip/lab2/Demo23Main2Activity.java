package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.demo1.R;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo23Main2Activity extends AppCompatActivity {
    ImageView imageView;
    TextView textView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo23_main2);
        imageView = findViewById(R.id.demo23Image);
        textView = findViewById(R.id.demo23TvKq);
        button = findViewById(R.id.demo23Btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Thread myThead = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //tao thread 1
                        final Bitmap bitmap =loadPic("http://tinypic.com/images/goodbye.jpg");
                        imageView.post(new Runnable() {
                            @Override
                            public void run() {
                                //tao thread 1.1
                                imageView.setImageBitmap(bitmap);
                                textView.setText("Thanh cong");
                            }
                        });
                    }
                });
                myThead.start();
            }
        });
    }
    private Bitmap loadPic(String link)
    {
        URL url;
        Bitmap bitmap = null;
        try {
            url = new URL(link);
            bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }
}
