package com.example.demo1.lab6;

import android.content.Context;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class FunctionGetDataVolley {
    //demo1: Doc du lieu dang chuoi
    public void getStringVolley(Context context, TextView textView) {
        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. url
        String url = "https://www.google.com/";
        //3. Truyen tham so
        //StringRequest(phuongThuc,Url,thanhcong,thatbai)
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //lay ve 1000 ky tu dau tien
                        textView.setText("Ketqua: " + response.substring(0, 1000));
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //4. Xu ly request
        queue.add(stringRequest);
    }

    //demo2: ham doc du lieu MANG cua cac DOI TUONG
    String stringJSON = "";

    public void getJSON_Array_Of_Objects(Context context, TextView textView) {
        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. url
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab3/array_json_new.json";
        //3. goi request (MANG cua cac DOI TUONG => goi mang truoc, doi tuong sau
        JsonArrayRequest request = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //chuyen mang -> doi tuong
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject person = response.getJSONObject(i);//lay ve 1 doi tuong
                        String name = person.getString("name");
                        String email = person.getString("email");
                        JSONObject phone = person.getJSONObject("phone");
                        String mobile = phone.getString("mobile");
                        String home = phone.getString("home");
                        //chuyen thanh chuoi
                        stringJSON += "Name: " + name + "\n\n";
                        stringJSON += "Email: " + email + "\n\n";
                        stringJSON += "Mobile: " + mobile + "\n\n";
                        stringJSON += "Home: " + home + "\n\n";
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                textView.setText(stringJSON);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //4. thuc thi request
        queue.add(request);
    }

    //demo2: ham doc du lieu MANG cua cac DOI TUONG
    public void getJSON_Object_Of_Arrays(Context context, TextView textView) {

        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. url
        String url = "";
        JsonObjectRequest request1 = new JsonObjectRequest(Request.Method.GET, url,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONArray person = response.getJSONArray("");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                textView.setText(stringJSON);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        })
        {

        };
        //4. thuc thi request
        queue.add(request1);
    }
}
