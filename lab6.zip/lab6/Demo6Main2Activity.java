package com.example.demo1.lab6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo6Main2Activity extends AppCompatActivity {
    Button btnGet;
    TextView tvResult;
    FunctionGetDataVolley fn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo6_main2);
        btnGet = findViewById(R.id.demo61Btn1);
        tvResult = findViewById(R.id.demo61Textview1);
        fn = new FunctionGetDataVolley();
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fn.getStringVolley(Demo6Main2Activity.this,tvResult);
                fn.getJSON_Array_Of_Objects(Demo6Main2Activity.this,tvResult);
            }
        });
    }
}
