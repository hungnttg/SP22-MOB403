package com.example.demo1.lab3;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo31Async extends AsyncTask<Void,Void,Void> {
    String path = Demo31Main2Activity.SERVER_LINK;//lay link server
    TextView tvResult;
    String strName,strMark;
    Context context;
    String kq = "";

    public Demo31Async(Context context, TextView tvResult,String strName,String strMark)
    {
        this.context = context;
        this.tvResult = tvResult;
        this.strMark = strMark;
        this.strName = strName;
    }
    @Override
    protected Void doInBackground(Void... voids) {
        path+="?name="+this.strName+"&mark="+this.strMark;
        try {
            URL url = new URL(path);//lay duong dan
            //bo loc doc du lieu
            BufferedReader bufferedReader
                    =new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));
            String line = "";//bien luu du lieu
            StringBuilder stringBuilder = new StringBuilder();
            while ((line=bufferedReader.readLine())!=null)//neu khong phai cuoi file, tiep tuc doc
            {
                stringBuilder.append(line);//dua dong doc duoc vao stringBuilder
            }
            kq = stringBuilder.toString();
        } catch (MalformedURLException e) {
            kq=e.getMessage();
            e.printStackTrace();
        } catch (IOException e) {
            kq=e.getMessage();
            e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        tvResult.setText(kq);
    }
}
