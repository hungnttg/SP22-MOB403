package com.example.demo1.lab3;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Demo32_Async_Post extends AsyncTask<Void,Void,Void> {
    String path  = Demo32Main2Activity.SERVER_PATH;//tham chieu duong dan
    Context context;
    String strCanh;
    TextView tvResult;
    String strKQ;
    public Demo32_Async_Post(Context context, String strCanh, TextView tvResult)
    {
        this.context = context;
        this.strCanh = strCanh;
        this.tvResult = tvResult;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try{
            //1. Lay duong dan
            URL url = new URL(path);
            //2. Xu ly tham so POST
            String param = "canh="+ URLEncoder.encode(strCanh,"utf-8");//truyen gia tri cho tham so canh
            //3. mo ket noi
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            //4. set thuoc tinh cho tham so post
            urlConnection.setDoOutput(true);//co lay output
            urlConnection.setRequestMethod("POST");//xac dinh phuong thuc lay du lieu
            urlConnection.setFixedLengthStreamingMode(param.getBytes().length);//do dai tham so
            //5. kieu thuoc tinh
            urlConnection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            //6. doc du lieu
            //6.1 lay ve tham so
            PrintWriter printWriter = new PrintWriter(urlConnection.getOutputStream());
            printWriter.print(param);
            printWriter.close();
            //6.2 tien hanh doc du lieu
            String line="";
            BufferedReader bufferedReader
                    =new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            StringBuilder stringBuilder = new StringBuilder();
            while ((line=bufferedReader.readLine())!=null)
            {
                stringBuilder.append(line);
            }
            strKQ = stringBuilder.toString();
            urlConnection.disconnect();

        }
        catch (Exception e)
        {
            strKQ = e.getMessage();
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        tvResult.setText(strKQ);
    }
}
