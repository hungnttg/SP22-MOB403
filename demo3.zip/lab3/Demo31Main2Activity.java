package com.example.demo1.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo31Main2Activity extends AppCompatActivity
implements View.OnClickListener {
    public static final String SERVER_LINK = "https://batdongsanabc.000webhostapp.com/mob403/demo2_api_get.php";
    EditText txtName,txtMark;
    Button btn;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        txtMark = findViewById(R.id.demo31TxtMark);
        txtName = findViewById(R.id.demo31TxtName);
        btn = findViewById(R.id.demo31BtnGet);
        tvResult = findViewById(R.id.demo31TvKQ);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String strName = txtName.getText().toString();
        String strMark = txtMark.getText().toString();
        Demo31Async demo31Async = new Demo31Async(this,tvResult,strName,strMark);
        demo31Async.execute();
    }
}
