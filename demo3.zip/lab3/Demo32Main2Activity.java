package com.example.demo1.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo32Main2Activity extends AppCompatActivity
implements View.OnClickListener
{
    public static final String SERVER_PATH = "https://batdongsanabc.000webhostapp.com/mob403/demo2_api_post.php";
    TextView tvKQ;
    EditText txtCanh;
    Button btnPost;
    String strCanh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        tvKQ = findViewById(R.id.demo32TvKq);
        btnPost = findViewById(R.id.demo32BtnPost);
        txtCanh = findViewById(R.id.demo32Txt);
        btnPost.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        strCanh = txtCanh.getText().toString();
        Demo32_Async_Post post = new Demo32_Async_Post(this,strCanh,tvKQ);
        post.execute();
    }
}
