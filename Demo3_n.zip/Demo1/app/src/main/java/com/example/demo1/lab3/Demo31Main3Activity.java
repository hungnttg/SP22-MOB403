package com.example.demo1.lab3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.demo1.R;

import java.util.ArrayList;

public class Demo31Main3Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main3);
        listView = findViewById(R.id.demo31Listview);
        getContacts();
        //requestPermission();
    }

    public void getContacts()
    {
        //1. Kiem tra quyen
        //b1. Vao menifest khai bao quyen
        //b2: Xin quyen bang code
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
        !=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]{
                    Manifest.permission.READ_CONTACTS
            },999);
        }
        else    //2 thuc hien doc du lieu
        {
            //2.1 duong dan
            Uri uri = Uri.parse("content://contacts/people");//duong dan lay danh ba
            ArrayList list = new ArrayList();//luu danh ba
            //2.2 contro
            Cursor cursor = getContentResolver().query(uri,null,null,null,null);
            //2.3. Kiem tra xem danh co du lieu khong
            if(cursor.getCount()>0)//neu co du lieu
            {
                cursor.moveToFirst();//chuyen con tro ve first record
                //2.4 - doc du lieu
                while (!cursor.isAfterLast())//neu khong phai record cuoi cung
                {
                    //2.4.1 lay thu tu luu trong danh ba
                    String thutu = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    //2.4.2 lay ten ban ghi
                    String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    //2.4.3 bat dau Lay so dien thoai
                        //2.4.3.1 - tao con tro truy van
                    Cursor cursorNumber=getContentResolver().query(
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID+"=? AND "+
                                    ContactsContract.CommonDataKinds.Phone.TYPE+"="+
                                    ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,new String[]{thutu},null
                            );
                    String contactNumber = null;
                    //2.4.3.2 lay so
                    if(cursorNumber.moveToFirst())
                    {
                        contactNumber =
                                cursorNumber.getString(cursorNumber.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }
                    cursorNumber.close();
                    //ket thuc lay so duen thoai
                    String thuTu_ten = thutu+" - "+ name+ " - "+contactNumber;//ghep thu tu va ten
                    list.add(thuTu_ten);//dua vao list
                    cursor.moveToNext();//chuyen ban ghi tiep theo
                }
                cursor.close();
                //2.5- Dua du lieu len listview
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(Demo31Main3Activity.this,
                        android.R.layout.simple_list_item_1, list);
                listView.setAdapter(adapter);
            }

        }

    }
    public boolean requestPermission()
    {
        if(Build.VERSION.SDK_INT>=23)//version lon hon 23
        {
            //kiem tra quyen xem duoc gan chua, neu gan roi, return true
            if(checkSelfPermission(Manifest.permission.WRITE_CONTACTS)==PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS)==PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED)
            {
                return true;
            }
            else //neu chua duoc gan, xin nguoi dung cap quyen, tra ve false
            {
                ActivityCompat.requestPermissions(Demo31Main3Activity.this,new String[]{
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.WRITE_CONTACTS,
                        Manifest.permission.READ_PHONE_NUMBERS,
                        Manifest.permission.READ_PHONE_STATE
                },1);
                return false;
            }
        }
        else
        {
            return true;
        }
    }
}
