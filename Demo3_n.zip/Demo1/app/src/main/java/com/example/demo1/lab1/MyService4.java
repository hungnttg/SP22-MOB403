package com.example.demo1.lab1;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService4 extends IntentService {
    long sogiay;//nhan tu Activity chuyen sang
    public MyService4()
    {
        super("MyService4");
    }
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        sogiay = intent.getLongExtra("second",1);
        try {
            Thread.sleep(sogiay*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this,"Service vua tam dung "+sogiay+" giay",Toast.LENGTH_LONG).show();
        super.onDestroy();
    }
}
