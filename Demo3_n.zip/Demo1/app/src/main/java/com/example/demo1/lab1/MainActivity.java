package com.example.demo1.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.demo1.R;

public class MainActivity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btnStart,btnStop;
    Intent intent1,intent2,intent3,intent4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt1 = findViewById(R.id.demo11Txt1);
        txt2 = findViewById(R.id.demo11Txt2);
        btnStart = findViewById(R.id.demo11BtnStart);
        btnStop = findViewById(R.id.demo11BtnStop);
        intent1 = new Intent(this,MyService1.class);
        intent2 = new Intent(this,MyService2.class);
        intent3 = new Intent(this,MyService3.class);
        intent4 = new Intent(this,MyService4.class);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                //startService(intent1);
//                //1. Lay du lieu nguoi dung nhap
//                String masv = txt1.getText().toString();
//                String tensv = txt2.getText().toString();
//                //2. dua vao intent
//                intent2.putExtra("masv",masv);
//                intent2.putExtra("tensv",tensv);
//                //3. truyen du lieu
//                startService(intent2);

//                //3.1 Lay ky tu nhap vao
//                String inputChar = txt2.getText().toString();
//                char[] c = inputChar.toCharArray();//chuyen chuoi thanh mang ky tu
//                //3.2 lay chuoi nhap vao
//                String check = txt1.getText().toString();
//                //3.3 dua chuoi va ky tu vao intent3
//                intent3.putExtra("char",c[0]);//dua ky tu vao intent
//                intent3.putExtra("check",check);//dua chuoi vao intent
//                //3.4 chuyen du lieu cho service
//                startService(intent3);

                //4.1 lay so giay nhap vao
                String sogiay = txt1.getText().toString();
                intent4.putExtra("second",Long.parseLong(sogiay));
                startService(intent4);


            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //stopService(intent1);
//                stopService(intent2);
            }
        });
    }
}
