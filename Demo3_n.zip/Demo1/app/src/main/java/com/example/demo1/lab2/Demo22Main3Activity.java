package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.demo1.R;

public class Demo22Main3Activity extends AppCompatActivity {
    Button button;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main3);
        button = findViewById(R.id.demo22Btn);
        editText = findViewById(R.id.demo22Txt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dulieu = editText.getText().toString();
                //1. Dua du lieu vao intent
                Intent intent = new Intent(Demo22Main3Activity.this,MyBroadcast2.class);
                intent.putExtra("br",dulieu);
                //2. gui du lieu sang broadcast
                sendBroadcast(intent);
            }
        });
    }
}
