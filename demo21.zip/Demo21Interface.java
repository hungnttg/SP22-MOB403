package com.example.demo1.lab2;

import android.graphics.Bitmap;

public interface Demo21Interface {
    void onloadImage(Bitmap bitmap);
    void onLoi();
}
