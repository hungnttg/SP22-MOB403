package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo21Main2Activity extends AppCompatActivity implements
        View.OnClickListener,Demo21Interface{
Button button;
ImageView imageView;
TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main2);
        textView = findViewById(R.id.demo21TvKQ);
        button = findViewById(R.id.demo21Btn);
        imageView = findViewById(R.id.demo21ImageView);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        //khi click button, ta goi den async
        new Demo21Async(this,this).execute("http://tinypic.com/images/goodbye.jpg");
    }

    @Override
    public void onloadImage(Bitmap bitmap) {
        imageView.setImageBitmap(bitmap);
    }

    @Override
    public void onLoi() {
        textView.setText("loi doc du lieu");
    }
}
